#!/bin/bash

sudo cp $PWD/qe/qe-6.3/bin/pw.x /usr/bin/pw
sudo cp $PWD/qe/qe-6.3/qe-gipaw-6.3/bin/gipaw.x /usr/bin/gipaw
